<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>




<?php 

if(isset($_POST['edit_p1_btn'])){
$product_category_id = $_POST['product_category_id'];
$category = $_POST['Category'];
	?>
	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Edit Category</h6>

		</div>
		<div class="card-body">


			<form action="code.php" method="POST" >

				<div class="form-group">
					<label>Category</label>
					<input type="text" name="edit_category"  value="<?php echo $category ; ?>" class="form-control" placeholder="Enter Category Name">
					

		<br></div>		
					<input type="hidden" name="product_category_id" value="<?php echo $product_category_id; ?>">
<center>

				<a href="Add_Category.php" class="btn btn-danger"> CANCEL </a>
		
				<button type="submit" name="edit_c1_btn" class="btn btn-primary"> Edit </button>
</center>
			</form>

			<?php 

		}

		?>

		<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
		?>