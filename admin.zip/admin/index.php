<?php 

header('location:Products.php');

?>