<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<div class="container-fluid">


<div class="card mb-4 py-3 border-bottom-primary">
                                <div class="card-body">
<center>   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
       Add Admin Profile 
</button> </center>
                                </div>
                            </div>
 <!-- Add Admin Section -->
      
 <div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Admin Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="code.php" method="POST">
        <div class="modal-body">

            <div class="form-group">
                <label> Username </label>
                <input type="text" name="Name" class="form-control" placeholder="Enter Username">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="Email" class="form-control checking_email" placeholder="Enter Email">
                <small class="error_email" style="color: red;"></small>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="Password" class="form-control" placeholder="Enter Password">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="CP" class="form-control" placeholder="Confirm Password">
            </div>
			
			 </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="Register_Btn" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


    <!-- Close Admin Section  -->
    <!-- Datatables Example -->
   
        <!-- <div class="card mb-4 py-3 border-left-primary">
                                <div class="card-body">
                    
            <form action="AddProducts.php" method="post">
                <h6 >
               <center>
                    <button  type="submit" name="add_product" class="btn btn-primary" data-toggle="modal" >
                       Add Product 
                   </button>
                 </center> 
               </form> 
           </h6> 
           </div>
            </div>
        </div> -->


        



   <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> All Products     </h6>
         </div>
            <div class="card-body">

                                     

         <?php  
            if(isset($_SESSION['success']) && $_SESSION['success'] != '')
            {
    echo '<h2 class="bg-primary"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status_code'] === 'success' )
{

    ?> 

    <div class="card mb-4 py-3 border-left-success">
    <div class="card-body">
<?php
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
?>
      </div>
      </div>
<?php

  }
  
if(isset($_SESSION['status']) && $_SESSION['status_code'] === 'error' )
{

    ?> 

    <div class="card mb-4 py-3 border-left-danger">
    <div class="card-body">
<?php
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
?>
      </div>
      </div>
<?php

  }
  ?>


  <div class="table-responsive">

    <?php
    $query = "SELECT * FROM product";
    $query_run = mysqli_query($connection, $query);

    $query3 = "SELECT * FROM category";
    $query_run3 = mysqli_query($connection, $query3);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
         <!--        <th> ID </th> -->
                 <th>Name </th>
                <th> Product </th>
                <th>Descriptions</th>
                <th>Cost Price</th>
                <th>Sell Price</th>
                <th>Discounted Price</th>
                <th>Items Sold</th>
                <th>Category</th>
                <th>EDIT</th>
                <th>EDIT IMAGE</th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            
             <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
                    
                    $id = $row['Product_ID'];
                    $cat_id = $row['Cat_ID'];
                    $query6 = "SELECT Image FROM image WHERE Prd_ID = '$id'";
                    $query_run6 = mysqli_query($connection, $query6);
                    $row6 = mysqli_fetch_assoc($query_run6);

                    $query3 = "SELECT * FROM category WHERE Cat_ID = '$cat_id'";
                    $query_run3 = mysqli_query($connection, $query3);
                    $row3 = mysqli_fetch_assoc($query_run3);
                    ?>
                    <tr>
                      
                        
                        <td><?php  echo $row['Name']; echo $row['Product_ID']; ?></td>
                        <td><img style="height: 80px ; width: 100px ;" src=<?php echo $row6['Image'];?>></td>
                        <td><?php  echo $row['Description']; ?></td>
                        <td><?php  echo $row['CP']; ?></td>
                        <td><?php  echo $row['SP']; ?></td>
                        <td><?php  echo $row['DP']; ?></td>
                        <td><?php  echo $row['ItemsSold']; ?></td>
                        <td><?php  echo $row3['Category']; ?></td>
                        
                        <td>
                            <form action="edit_product.php" method="post">
                                <input type="hidden" name="Product_ID" value="<?php echo $row['Product_ID']; ?>">
                                <button type="submit" name="product_edit_btn" class="btn btn-success"> EDIT</button>
                            </form>
                        </td>
                        <td>
                            <form action="Images.php" method="post">
                                <input type="hidden" name="Product_ID" value="<?php echo $row['Product_ID']; ?>">
                                <!-- <input type="hidden" name="Image_ID" value="<?php //echo $row['Image_ID']; ?>"> -->
                                <button type="submit" name="image_edit_btn" class="btn btn-success"> EDIT</button>
                            </form>
                        </td>
                        <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row['Product_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger" onclick="javascript: return confirm('Are you sure you want to DELETE this product ?')"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                } 
            }
    
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>
</div>
<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>