<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>




		<?php 

		// if(isset($_POST['add_product'])){
			$query = "SELECT * FROM Category";
			$query_run = mysqli_query($connection, $query);
			?>
<!-- Datatables Example -->
<div class="card shadow mb-4">
	<div class="card-header py-3">
		<h6 class="n-0 font-weight-bold text-primary">Add Product</h6>

	</div>
	<div class="card-body">


			<form action="code.php" method="POST" enctype="multipart/form-data">




				<div class="form-group">
					<label> Product Photo </label>
					<input type="file" name="files[]"  class="form-control" multiple>

				</div>
				<div class="form-group">
					<label>Product Name</label>
					<input type="text" name="Name"  value="" class="form-control" placeholder="Enter Product Name">

				</div>
				<div class="form-group">
					<label>Product Description</label>
					<input type="text" name="Description"  value="" class="form-control" placeholder="Enter Product Description">
				</div>
				<div class="form-group">
					<label>Cost Price</label>
					<input type="number" name="CP"  value="" class="form-control " placeholder="Enter Cost Price">

				</div>
				<div class="form-group">
					<label>Selling Price</label>
					<input type="number" name="SP" value="" class="form-control" placeholder="Enter Selling Price">
				</div>
				<div class="form-group">
					<label>Discount Price</label>
					<input type="number" name="DP" value="" class="form-control" placeholder="Enter Discounted Price">
				</div>
				<div class="form-group">
					<label>Items Sold</label>
					<input type="number" name="ItemsSold" value="" class="form-control" placeholder="Enter Reviews">
				</div>
				<div class="form-group">
					<label>Category</label>
					<select name="Category" class="form-control" placeholder="Select Category" id="formoptions" >
                         <option value="" >Select Category</option>
						 <?php
  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{
  					?>
                         <option value="<?php  echo $row['Cat_ID'];?>" ><?php  echo $row['Category'];?></option>
						 <?php
  		}}
  					?>
                    
                     </select>
				</div>

<br>

			<center><a href="Products.php" class="btn btn-danger"> CANCEL </a>

				<button type="submit" name="add_product_btn" class="btn btn-primary"> Add </button>
</center>	
			</form>

			<?php 

		// }

		?>

		

	</div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>