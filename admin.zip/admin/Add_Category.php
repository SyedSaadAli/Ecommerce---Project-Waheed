<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="Add.php" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>
					<button  type="submit" name="add_category" class="btn btn-primary">
						ADD Product Category
					</button>
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"> Product Categorys


				</h6> </div>
				<div class="card-body">

		                                    

				<?php  
            if(isset($_SESSION['success']) && $_SESSION['success'] != '')
            {
    echo '<h2 class="bg-primary"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status_code'] === 'success' )
{

    ?> 

    <div class="card mb-4 py-3 border-left-success">
    <div class="card-body">
<?php
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
?>
      </div>
      </div>
<?php

  }
  
if(isset($_SESSION['status']) && $_SESSION['status_code'] === 'error' )
{

    ?> 

    <div class="card mb-4 py-3 border-left-danger">
    <div class="card-body">
<?php
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
?>
      </div>
      </div>
<?php

  }
  ?>


  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM category";
  	$query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				<!-- <th> ID </th> -->
  				<th>Category </th>
  				<th>EDIT Category</th>
  				<th>DELETE</th>
  			</tr>
  		</thead>
  		<tbody>
  			<?php
  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{
  					?>
  					<tr>
  					<!-- 	<td><?php  //echo $row['Product_Category_ID']; ?></td> -->
  						<td><?php  echo $row['Category'];?></td>

  	
<td>
  							<form action="Edit.php" method="post">
  								<input type="hidden" name="product_category_id" value="<?php echo $row['Cat_ID']; ?>">
  									<input type="hidden" name="Category" value="<?php echo $row['Category']; ?>">
  								<button type="submit" name="edit_p1_btn" class="btn btn-primary " onclick="javascript: return confirm('Are you sure you want to EDIT this category ?')"> EDIT</button>
  							</form>
  						</td>
						    	
<td>
  							<form action="code.php" method="post">
  								<input type="hidden" name="product_category_id" value="<?php echo $row['Cat_ID']; ?>">
  									<input type="hidden" name="Category" value="<?php echo $row['Category']; ?>">
  								<button type="submit" name="C_delete_btn" class="btn btn-danger " onclick="javascript: return confirm('Are you sure you want to DELETE this category ?')"> DELETE</button>
  							</form>
  						</td>
<?php
}}
?>
  						

  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>



<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>