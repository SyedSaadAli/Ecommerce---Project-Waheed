<?php
 include('security.php');
 include('CheckLogin.php');
 include('includes/header.php'); 
 include('includes/navbar.php'); 
?>


<!-- Datatables Example -->
<div class="card shadow mb-4">
<div class="card-header py-3">
<h6 class="n-0 font-weight-bold text-primary">EDIT Product</h6>

</div>
<div class="card-body">
<?php 
if(isset($_POST['product_edit_btn'])){
	$id = $_POST['Product_ID'];

	$query = "SELECT * FROM product WHERE Product_ID='$id' ";
            $query_run = mysqli_query($connection, $query);

			foreach($query_run as $row){

?>

 <form action="code.php" method="POST" enctype="multipart/form-data">
 <input type="hidden" name="p_edit_id" value="<?php echo $_POST['Product_ID'] ?>">

                           
              <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="edit_Name" value="<?php echo $row['Name'] ?>" class="form-control" placeholder="Enter Product Name">
               
            </div>
            
            <div class="form-group">
                <label>Description</label>
                <input type="text" name="edit_Description" value="<?php echo $row['Description'] ?>" class="form-control" placeholder="Enter Product Description">
            </div>
            <div class="form-group">
                <label>Cost Price</label>
                <input type="number" name="edit_CP" value="<?php echo $row['CP'] ?>" class="form-control " placeholder="Enter Cost Price">
               
            </div>
            <div class="form-group">
                <label>Sales Price</label>
                <input type="number" name="edit_SP" value="<?php echo $row['SP'] ?>" class="form-control " placeholder="Enter Selling Price">
               
            </div>
            <div class="form-group">
                <label>Discounted Price</label>
                <input type="number" name="edit_DP" value="<?php echo $row['DP'] ?>" class="form-control " placeholder="Enter Discounted Price">
               
            </div>
       
            <div class="form-group">
                <label>Items Sold</label>
                <input type="number" name="edit_ItemsSold" value="<?php echo $row['ItemsSold'] ?>" class="form-control" placeholder="Enter Product Reviews">
            </div>
            

			
			
			
		  <center><a href="Products.php" class="btn btn-danger"> CANCEL </a>
        
             <button type="submit" name="prd_updatebtn" class="btn btn-primary"> Update </button>
             </center>  

                        </form>

			<?php 
			}
			 }
			
			?>


      </div>
</div>
</div>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>