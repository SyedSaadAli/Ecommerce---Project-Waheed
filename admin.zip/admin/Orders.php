<?php

 include('security.php');
 include('CheckLogin.php');
 include('includes/header.php'); 
 include('includes/navbar.php'); 
?>
<div class="container-fluid">
<div class="card-header py-3">
<h6 class="n-0 font-weight-bold text-primary">Customers Orders
</h6> </div>
<div class="card-body">
                      

<?php  
            if(isset($_SESSION['success']) && $_SESSION['success'] != '')
            {
    echo '<h2 class="bg-primary"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status_code'] === 'success' )
{

    ?> 

    <div class="card mb-4 py-3 border-left-success">
    <div class="card-body">
<?php
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
?>
      </div>
      </div>
<?php

  }
  
if(isset($_SESSION['status']) && $_SESSION['status_code'] === 'error' )
{

    ?> 

    <div class="card mb-4 py-3 border-left-danger">
    <div class="card-body">
<?php
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
?>
      </div>
      </div>
<?php

  }
  ?>


     <div class="table-responsive">

    <?php
                $query = "SELECT * FROM ordernow";
                $query_run = mysqli_query($connection, $query);
            ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th> ID </th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Quantity</th>
                            <th>City</th>
                            <th>Address </th>
                            <th>Status </th>
                            <th>Inprocess </th>
                            <th>Delivered </th>
                            
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php



                        if(mysqli_num_rows($query_run) > 0)        
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                              
                        ?>
                            <tr>
                                <td><?php  echo $row['Order_ID']; ?></td>
                                <td><?php  echo $row['FullName']; ?></td>
                                <td><?php  echo $row['Mobile']; ?></td>
                                <td><?php  echo $row['Quantity']; ?></td>
                                <td><?php  echo $row['City']; ?></td>
                                <td><?php  echo $row['Address']; ?></td>
                         
                                <td><?php  echo $row['Status']; ?></td>
                                 <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="Order_ID" value="<?php echo $row['Order_ID']; ?>">
                                <button type="submit" name="Inprocess_btn" class="btn btn-success" onclick="javascript: return confirm('Are you sure you want to change the STATUS to Inprocess ?')"> Inprocess</button>
                            </form>
                        </td>
                         <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="Order_ID" value="<?php echo $row['Order_ID']; ?>">
                                <button type="submit" name="Delivered_btn" class="btn btn-success" onclick="javascript: return confirm('Are you sure you want to change the STATUS to Delivered ?')"> Delivered</button>
                            </form>
                        </td>
                                

                               
                            </tr>
                        <?php
                            } 
                        }
                    
                        else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>

        </div>
</div>
</div>
</div>
<!-- /.container-fluid -->

<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>