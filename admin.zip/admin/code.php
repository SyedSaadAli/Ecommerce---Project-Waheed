<?php 
include('security.php');



// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['Register_Btn']))
{
    // echo "Working";

    $Name = $_POST['Name'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    $CP = $_POST['CP'];

   
if($Password === $CP){

    $Password = password_hash($Password ,PASSWORD_BCRYPT);

    $query = "INSERT INTO admin (Name,Email,Password) VALUES ('$Name','$Email','$Password')";
    $query_run = mysqli_query($connection, $query);
    
    if($query_run)
    {
        $_SESSION['status'] = "Admin Is ADDED. Thank you!";
        $_SESSION['status_code'] = "success";
        header('Location: Products.php'); 
    }
    else 
    {
        $_SESSION['status'] = "Admin Is Not ADDED. Thank you!";
        $_SESSION['status_code'] = "error";
        header('Location: Products.php'); 
    }        

}else{
    $_SESSION['status'] = "Password and Confirm Password does not match. Thank you!";
        $_SESSION['status_code'] = "error";
    header('Location: Products.php'); 
}


}

// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add_product_btn'])){     //1
    $Name = $_POST['Name'];
    $Description = $_POST['Description'];
    $CP = $_POST['CP'];
    $SP = $_POST['SP'];
    $DP = $_POST['DP'];
    $ItemsSold  = $_POST['ItemsSold'];
    $Category = $_POST['Category'];



    $query1 = "SELECT * FROM product";
    $query_run1 = mysqli_query($connection, $query1);
    if(mysqli_num_rows($query_run1) > 0)        
    {
        while($row = mysqli_fetch_assoc($query_run1))
        {
            $id = $row['Product_ID'] + 1;

        }
    }
    else {
        $id = 1 ;
    }


    $query2 = "INSERT INTO product (Name,Description,CP,SP,DP,ItemsSold,Cat_ID) VALUES 
    ('$Name','$Description','$CP','$SP','$DP','$ItemsSold','$Category')";
    $query_run2 = mysqli_query($connection, $query2);


  // Configure upload directory and allowed file types
    $upload_dir = 'Products/';
    $allowed_types = array('jpg', 'png', 'jpeg', 'gif');

    // Define maxsize for files i.e 10MB
    $maxsize = 10 * 1024 * 1024;

    // Checks if user sent an empty form
    if(!empty(array_filter($_FILES['files']['name']))) {  //2

        // Loop through each file in files[] array
        foreach ($_FILES['files']['tmp_name'] as $key => $value) {  //3


            $file_tmpname = $_FILES['files']['tmp_name'][$key];
            $file_name = $_FILES['files']['name'][$key];
            $file_size = $_FILES['files']['size'][$key];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
             
            // Set upload file path
            $filepath = $upload_dir.$file_name;

            // Check file type is allowed or not
            if(in_array(strtolower($file_ext), $allowed_types)){ //4

                // Verify file size - 2MB max
                // if ($file_size > $maxsize)        
                //     echo "Error: File size is larger than the allowed limit.";

                // If file with name already exist then append time in
                // front of name of the file to avoid overwriting of file
                if(file_exists($filepath)) { //5 
                    $filepath = $upload_dir.time().$file_name; 

                    if( move_uploaded_file($file_tmpname, $filepath)) {  //5.1
                        echo "{$file_name} successfully uploaded <br />";
                      } //5.1
                    else {   //5.2                
                        echo "Error uploading {$file_name} <br />";
                    } //5.2
                    $query5 = "INSERT INTO image (Image,Prd_ID) VALUES ('$filepath','$id')";
                    $query_run5 = mysqli_query($connection, $query5);
                } //5
                else { //6
                       $query6 = "INSERT INTO image (Image,Prd_ID) VALUES ('$filepath','$id')";
                       $query_run6 = mysqli_query($connection, $query6);
                    if( move_uploaded_file($file_tmpname, $filepath)) { //6.1
                        echo "{$file_name} successfully uploaded <br />";
                        } //6.1
                        else {     //6.2                
                        echo "Error uploading {$file_name} <br />";
                    }  //6.2
                } //6
            }    //4

            else { //4.1

                // If file extension not valid
                echo "Error uploading {$file_name} ";
                echo "({$file_ext} file type is not allowed)<br / >";
            }  //4.2


        }  //3

    }  //2


    if($query_run2)
    {
        $_SESSION['status'] = "Product Added";
        $_SESSION['status_code'] = "success";
        header('Location: Products.php'); 
    }
    else
    {
        $_SESSION['status'] = "Product is NOT Added";
        $_SESSION['status_code'] = "error";
        header('Location: products.php');  
    }


} //1


// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['prd_updatebtn']))
{
    $id = $_POST['p_edit_id'];
    $edit_Name = $_POST['edit_Name'];
    $edit_Description = $_POST['edit_Description'];
    $edit_CP = $_POST['edit_CP'];
    $edit_SP = $_POST['edit_SP'];
    $edit_DP = $_POST['edit_DP'];
  
    $edit_ItemsSold = $_POST['edit_ItemsSold'];

    $query = "UPDATE product SET  Name='$edit_Name' , Description='$edit_Description', CP='$edit_CP', SP='$edit_SP',  DP='$edit_DP',ItemsSold='$edit_ItemsSold' WHERE Product_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Product is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Products.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Product is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: products.php');  
    }
}



// ----------------------------------------------------------------------------------------------------------

if(isset($_POST['image_edit_btn']))
{
    $Image = $_POST['Image'];
    $Image_ID = $_POST['Prd_ID'];
    $edit_image = $_POST['edit_image'];

    $target_dir = "Products/";
    $target_file = $target_dir . basename($_FILES["edit_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["edit_image"]["tmp_name"]);
    if($check !== false) {
   # echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
        $ImageName = $_FILES['edit_image']['name'];
        $fileElementName = 'edit_image';
        $path = 'Products/'; 
        $location = $path . $_FILES['edit_image']['name']; echo $location;

        move_uploaded_file($_FILES['edit_image']['tmp_name'], $location); 
    } else {
   # echo "File is not an image.";
        $uploadOk = 0;
    }


    $query = "UPDATE image SET Image='$location' , Prd_ID='$Image_ID'  WHERE Prd_ID='$Image_ID' AND Image='$Image' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Image is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Images.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Image is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Images.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['p_delete_btn']))
{
    $id = $_POST['p_delete_id'];

    $query1 = "DELETE FROM image WHERE Prd_ID='$id' ";
    $query_run1 = mysqli_query($connection, $query1);

    $query = "DELETE FROM product WHERE Product_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Product is Deleted";
        $_SESSION['status_code'] = "success";
        header('Location: Products.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Product is NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: Products.php'); 
    }    
}




// ----------------------------------------------------------------------------------------------------------

if(isset($_POST['Inprocess_btn']))
{
    $id = $_POST['Order_ID'];



    $query = "UPDATE ordernow SET  Status='Inprocess' WHERE Order_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Order Status is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Orders.php'); 
    }
    else
    {
        $_SESSION['status'] = "Order Status is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Orders.php');  
    }
}

if(isset($_POST['Delivered_btn']))
{
    $id = $_POST['Order_ID'];



    $query = "UPDATE ordernow SET  Status='Delivered' WHERE Order_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Order Status is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: Orders.php'); 
    }
    else
    {
        $_SESSION['status'] = "Order Status is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: Orders.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------


  // ----------------------------------------------------------------------------------------------------------
  

  if(isset($_POST['add_c_btn']))
  {
  
      $add_category = $_POST['add_category'];
  
      $query = "INSERT INTO category (Category) VALUES 
      ('$add_category')";
      $query_run = mysqli_query($connection, $query);
  
  
      if($query_run)
      {
          $_SESSION['status'] = "New Category is Added. Thank you!";
          $_SESSION['status_code'] = "success";
          header('Location: Add_Category.php'); 
      }
      else
      {
          $_SESSION['status'] = "Your Category is NOT Added. Thank you!";
          $_SESSION['status_code'] = "error";
          header('Location: Add_Category.php');  
      }
  }
  
  
  // ----------------------------------------------------------------------------------------------------------
  
  
  if(isset($_POST['C_delete_btn']))
  {
      $id = $_POST['product_category_id'];
      $Category = $_POST['Category'];
  
      // echo $id;
      // echo $Category;
      // exit();
  
  
      $query2 = "SELECT * FROM product";
      $query_run2 = mysqli_query($connection, $query2);
      if(mysqli_num_rows($query_run2) > 0)        
      {
          while($row2 = mysqli_fetch_assoc($query_run2))
          {
              if($Category === $row2['Category'])
              {
                  $id2 = $row2['Product_ID'];
                  $query3 = "DELETE FROM product WHERE product_ID='$id2' ";
                  $query_run3 = mysqli_query($connection, $query3);
              }
          }
      }
  
      $query = "DELETE FROM category WHERE Cat_ID='$id' ";
      $query_run = mysqli_query($connection, $query);
  
      if($query_run)
      {
          $_SESSION['status'] = "Your selected product category is Deleted. Thank you!";
          $_SESSION['status_code'] = "success";
          header('Location: Add_Category.php'); 
      }
      else
      {
          $_SESSION['status'] = "Your selected product category is NOT DELETED. Thank you!";       
          $_SESSION['status_code'] = "error";
          header('Location: Add_Category.php'); 
      }    
  }
  



// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['edit_c1_btn']))
{
    $id = $_POST['product_category_id'];
    $edit_category = $_POST['edit_category'];

    $query = "UPDATE category SET Category='$edit_category' WHERE Cat_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your selected product category is Edited. Thank you!";
          $_SESSION['status_code'] = "success";
        header('Location: Add_Category.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your selected product category is NOT Edited. Thank you!";       
          $_SESSION['status_code'] = "error";
        header('Location: Add_Category.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------





?>