<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>




<?php 

if(isset($_POST['add_category'])){

	?>
	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Add Category</h6>

		</div>
		<div class="card-body">


			<form action="code.php" method="POST" >

				<div class="form-group">
					<label>Category</label>
					<input type="text" name="add_category"  value="" class="form-control" placeholder="Enter Category Name">
					

		<br></div>		
<center>

				<a href="Add_Category.php" class="btn btn-danger"> CANCEL </a>
				
				<button type="submit" name="add_c_btn" class="btn btn-primary"> Add </button>
</center>
			</form>

			<?php 

		}

		?>

		<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
		?>