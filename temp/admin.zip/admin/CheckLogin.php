<?php
if($_SESSION['role'] != "teacher")
{
	//header('location:../Login_Page.html');
}
?>